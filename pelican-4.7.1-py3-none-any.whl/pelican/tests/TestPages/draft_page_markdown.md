title: This is a markdown test draft page
status: draft

Test Markdown File Header
=========================

Used for pelican test
---------------------

The quick brown fox .

This page is a draft