Title: Article with markdown and nested summary metadata
Date: 2012-10-30
Summary: Test: This metadata value looks like metadata

This is some content.
