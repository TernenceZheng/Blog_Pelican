This is an article with multiple authors!
#########################################

:date: 2014-02-09 02:20
:modified: 2014-02-09 02:20
:authors: First Author, Second Author
