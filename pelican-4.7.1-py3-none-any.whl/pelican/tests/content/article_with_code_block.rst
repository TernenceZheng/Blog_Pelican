An Article With Code Block To Test Typogrify Ignore
###################################################

An article with some code

.. code-block:: python

   x & y

A block quote:

   x & y

Normal:
x & y
