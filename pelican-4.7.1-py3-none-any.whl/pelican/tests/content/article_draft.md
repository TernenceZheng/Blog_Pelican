Title: Draft article
Date: 2012-10-31
Status: draft

This is some content.
