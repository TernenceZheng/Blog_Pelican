
This is a super article !
#########################

:TAGS: foo, bar, foobar
:DATE: 2010-12-02 10:14
:MODIFIED: 2010-12-02 10:20
:CATEGORY: yeah
:AUTHOR: Alexis Métaireau
:SUMMARY:
    Multi-line metadata should be supported
    as well as **inline markup** and stuff to "typogrify"...
:CUSTOM_FIELD: http://notmyidea.org
:CUSTOM_FORMATTED_FIELD:
    Multi-line metadata should also be supported
    as well as *inline markup* and stuff to "typogrify"...
