Title: Article with markdown and empty tags
Tags:

This is some content.
